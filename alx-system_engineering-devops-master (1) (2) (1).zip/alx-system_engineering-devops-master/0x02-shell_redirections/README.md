0. Hello World 
Write a script that prints “Hello, World”, followed by a new line to the standard output.
