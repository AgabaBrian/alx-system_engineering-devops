# What happens when you type google.com in your browser and press Enter
With this project we were tasked to write an article that explains exactly what happens when you type google.com in your browser and press enter. Below is a link to my published article:

  https://blog.ehoneahobed.com/what-happens-when-you-type-wwwgooglecom-in-your-browser-and-press-enter