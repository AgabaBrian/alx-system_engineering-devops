# Solutions to tasks on MySQL
