Projects on Shell variables and shell expansions
